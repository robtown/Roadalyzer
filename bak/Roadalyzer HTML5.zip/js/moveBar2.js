﻿function moveBox2(stage2, x) {
    var context = stage2;
    context.attrs.x = x;
    context.draw();
}
function moveBox1(stage1, x) {
    var context = stage1;
    context.attrs.x = x;
    context.draw();
}