﻿function figureScaleFeet(val) {
    switch (val) {
        case "100 ft":
            return 100;
            break;
        case "250 ft":
            return 250;
            break;
        case "500 ft":
            return 500;
            break;
        case "1000 ft":
            return 1000;
            break;
        case "2000 ft":
            return 2000;
            break;
        case "1 mi":
            return 5280;
            break;
        case "2 mi":
            return 10560;
            break;
        case "5 mi":
            return 26400;
            break;
        case "10 mi":
            return 52800;
            break;
    }
}
function figureScaleUnits(val){
    switch (val) {
        case "100 ft":
            return "ft";
            break;
        case "250 ft":
            return "ft";
            break;
        case "500 ft":
            return "ft";
            break;
        case "1000 ft":
            return "ft";
            break;
        case "2000 ft":
            return "ft";
            break;
        case "1 mi":
            return "mi";
            break;
        case "2 mi":
            return "mi";
            break;
        case "5 mi":
            return "mi";
            break;
        case "10 mi":
            return "mi";
            break;
    }
}



function scaleCanvases(scalefactor) {
    
}